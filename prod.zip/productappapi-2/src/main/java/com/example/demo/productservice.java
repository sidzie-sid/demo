package com.verizon.service;

import com.verizon.dao.ProductDAO;
import com.verizon.exception.ProductNotFoundException;
import com.verizon.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class productservice {

    @Autowired
    private ProductDAO productDAO;

    public void addProduct(Product product) {
        productDAO.save(product);
    }

    public List<Product> getAllProducts() {
        return productDAO.findAll();
    }

    public Product getProductById(Integer id) throws ProductNotFoundException {
        return productDAO.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with id " + id));
    }

    public List<Product> getAllProductsBetweenPrice(Integer low, Integer high) {
        return productDAO.findProductsBetweenPrice(low, high);
    }

    public void updateProduct(Integer id, Product product) throws ProductNotFoundException {
        if (!productDAO.existsById(id)) {
            throw new ProductNotFoundException("Product not found with id " + id);
        }
        product.setId(id);
        productDAO.save(product);
    }

    public void deleteProduct(Integer id) throws ProductNotFoundException {
        if (!productDAO.existsById(id)) {
            throw new ProductNotFoundException("Product not found with id " + id);
        }
        productDAO.deleteById(id);
    }
}
